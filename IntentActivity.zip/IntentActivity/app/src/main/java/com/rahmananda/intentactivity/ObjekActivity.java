package com.rahmananda.intentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ObjekActivity extends AppCompatActivity {

    private TextView tvActivityObjek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objek);

        tvActivityObjek = findViewById(R.id.tv_activityobjek);

        MahasiswaModel datamahasiswa = getIntent().getParcelableExtra("MAHASISWA");

        String namaMhs = datamahasiswa.getNama();
        String asalMhs = datamahasiswa.getAsal();
        String ptMhs = datamahasiswa.getPt();
        int umurMhs = datamahasiswa.getUmur();
        int angktMhs = datamahasiswa.getAngkatan();

        tvActivityObjek.setText(namaMhs+"\n"+asalMhs+"\n"+ptMhs+"\n"+umurMhs+"\n"+angktMhs);

    }
}
