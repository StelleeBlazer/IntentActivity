package com.rahmananda.intentactivity;

import android.os.Parcel;
import android.os.Parcelable;

public class MahasiswaModel implements Parcelable {

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAsal() {
        return asal;
    }

    public void setAsal(String asal) {
        this.asal = asal;
    }

    public String getPt() {
        return pt;
    }

    public void setPt(String pt) {
        this.pt = pt;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }

    String nama, asal, pt;
    int umur, angkatan;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.nama);
        dest.writeString(this.asal);
        dest.writeString(this.pt);
        dest.writeInt(this.umur);
        dest.writeInt(this.angkatan);
    }

    public MahasiswaModel() {
    }

    protected MahasiswaModel(Parcel in) {
        this.nama = in.readString();
        this.asal = in.readString();
        this.pt = in.readString();
        this.umur = in.readInt();
        this.angkatan = in.readInt();
    }

    public static final Parcelable.Creator<MahasiswaModel> CREATOR = new Parcelable.Creator<MahasiswaModel>() {
        @Override
        public MahasiswaModel createFromParcel(Parcel source) {
            return new MahasiswaModel(source);
        }

        @Override
        public MahasiswaModel[] newArray(int size) {
            return new MahasiswaModel[size];
        }
    };
}
