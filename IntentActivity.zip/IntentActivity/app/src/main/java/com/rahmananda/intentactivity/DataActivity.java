package com.rahmananda.intentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DataActivity extends AppCompatActivity {

    private TextView tvActivityData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        tvActivityData = findViewById(R.id.tv_activitydata);

        String nama = getIntent().getStringExtra("NAMA");
        int umur =  getIntent().getIntExtra("UMUR",0);
        String asal = getIntent().getStringExtra("ASAL");

        tvActivityData.setText(nama+"\n "+umur+"\n "+asal);
    }
}
