package com.rahmananda.intentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.rahmananda.intentactivity.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //deklarasi
    private Button btnActivity,btnActivityData,btnActivityObjek,btnDialPhone;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialisasi
        btnActivity = findViewById(R.id.btn_intent_pindah_activity);
        btnActivityData = findViewById(R.id.btn_intent_pindah_activity_bawa_data);
        btnActivityObjek = findViewById(R.id.btn_intent_pindah_activity_bawa_objek);
        btnDialPhone = findViewById(R.id.btn_intent_dial_phone);

        btnActivity.setOnClickListener(this);
        btnActivityData.setOnClickListener(this);
        btnActivityObjek.setOnClickListener(this);
        btnDialPhone.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        switch (id){
            case R.id.btn_intent_pindah_activity:

                Intent intent1 = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent1);
                break;

            case R.id.btn_intent_pindah_activity_bawa_data:

                Intent intent2 = new Intent(MainActivity.this, DataActivity.class);
                intent2.putExtra("NAMA","RAHMANANDA");
                intent2.putExtra("UMUR",15);
                intent2.putExtra("ASAL","JAKARTA BARAT");
                startActivity(intent2);
                break;

            case  R.id.btn_intent_pindah_activity_bawa_objek:

                MahasiswaModel objekmahasiswa = new MahasiswaModel();
                objekmahasiswa.setNama("RAHMANANDA");
                objekmahasiswa.setAsal("JAKARTA BARAT");
                objekmahasiswa.setPt("BINUS UNIVERSITY");
                objekmahasiswa.setUmur(15);
                objekmahasiswa.setAngkatan(2020);

                Intent intent3 = new Intent(MainActivity.this, ObjekActivity.class);
                intent3.putExtra("MAHASISWA",objekmahasiswa);
                startActivity(intent3);
                break;


            case R.id.btn_intent_dial_phone:
                String noHape = "081295951620";
                Intent dialphone = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+noHape));
                startActivity(dialphone);
                break;

        }

    }
}
